import {
    _ as pe,
    r as u,
    a as Ne,
    b as Le,
    c as Ie,
    R as je
} from "./components-Au9m-AvA.js";
var Ue = /&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g,
    Te = {
        "&amp;": "&",
        "&#38;": "&",
        "&lt;": "<",
        "&#60;": "<",
        "&gt;": ">",
        "&#62;": ">",
        "&apos;": "'",
        "&#39;": "'",
        "&quot;": '"',
        "&#34;": '"',
        "&nbsp;": " ",
        "&#160;": " ",
        "&copy;": "©",
        "&#169;": "©",
        "&reg;": "®",
        "&#174;": "®",
        "&hellip;": "…",
        "&#8230;": "…",
        "&#x2F;": "/",
        "&#47;": "/"
    },
    ke = function(t) {
        return Te[t]
    },
    Be = function(t) {
        return t.replace(Ue, ke)
    };

function Q(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(i) {
            return Object.getOwnPropertyDescriptor(e, i).enumerable
        })), n.push.apply(n, r)
    }
    return n
}

function Z(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {};
        t % 2 ? Q(Object(n), !0).forEach(function(r) {
            pe(e, r, n[r])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Q(Object(n)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(n, r))
        })
    }
    return e
}
var M = {
        bindI18n: "languageChanged",
        bindI18nStore: "",
        transEmptyNodeValue: "",
        transSupportBasicHtmlNodes: !0,
        transWrapTextNodes: "",
        transKeepBasicHtmlNodesFor: ["br", "strong", "i", "p"],
        useSuspense: !0,
        unescape: Be
    },
    me, _e = u.createContext();

function Fe() {
    var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    M = Z(Z({}, M), e)
}

function $e() {
    return M
}
var We = function() {
    function e() {
        Le(this, e), this.usedNamespaces = {}
    }
    return Ne(e, [{
        key: "addUsedNamespaces",
        value: function(n) {
            var r = this;
            n.forEach(function(i) {
                r.usedNamespaces[i] || (r.usedNamespaces[i] = !0)
            })
        }
    }, {
        key: "getUsedNamespaces",
        value: function() {
            return Object.keys(this.usedNamespaces)
        }
    }]), e
}();

function De(e) {
    me = e
}

function Ae() {
    return me
}
var Zt = {
    type: "3rdParty",
    init: function(t) {
        Fe(t.options.react), De(t)
    }
};

function Me() {
    if (console && console.warn) {
        for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
        typeof n[0] == "string" && (n[0] = "react-i18next:: ".concat(n[0])), (e = console).warn.apply(e, n)
    }
}
var ee = {};

function z() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
    typeof t[0] == "string" && ee[t[0]] || (typeof t[0] == "string" && (ee[t[0]] = new Date), Me.apply(void 0, t))
}

function te(e, t, n) {
    e.loadNamespaces(t, function() {
        if (e.isInitialized) n();
        else {
            var r = function i() {
                setTimeout(function() {
                    e.off("initialized", i)
                }, 0), n()
            };
            e.on("initialized", r)
        }
    })
}

function ze(e, t) {
    var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {},
        r = t.languages[0],
        i = t.options ? t.options.fallbackLng : !1,
        o = t.languages[t.languages.length - 1];
    if (r.toLowerCase() === "cimode") return !0;
    var a = function(l, c) {
        var d = t.services.backendConnector.state["".concat(l, "|").concat(c)];
        return d === -1 || d === 2
    };
    return n.bindI18n && n.bindI18n.indexOf("languageChanging") > -1 && t.services.backendConnector.backend && t.isLanguageChangingTo && !a(t.isLanguageChangingTo, e) ? !1 : !!(t.hasResourceBundle(r, e) || !t.services.backendConnector.backend || t.options.resources && !t.options.partialBundledLanguages || a(r, e) && (!i || a(o, e)))
}

function Ve(e, t) {
    var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    if (!t.languages || !t.languages.length) return z("i18n.languages were undefined or empty", t.languages), !0;
    var r = t.options.ignoreJSONStructure !== void 0;
    return r ? t.hasLoadedNamespace(e, {
        precheck: function(o, a) {
            if (n.bindI18n && n.bindI18n.indexOf("languageChanging") > -1 && o.services.backendConnector.backend && o.isLanguageChangingTo && !a(o.isLanguageChangingTo, e)) return !1
        }
    }) : ze(e, t, n)
}

function ne(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(i) {
            return Object.getOwnPropertyDescriptor(e, i).enumerable
        })), n.push.apply(n, r)
    }
    return n
}

function D(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {};
        t % 2 ? ne(Object(n), !0).forEach(function(r) {
            pe(e, r, n[r])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ne(Object(n)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(n, r))
        })
    }
    return e
}
var qe = function(t, n) {
    var r = u.useRef();
    return u.useEffect(function() {
        r.current = t
    }, [t, n]), r.current
};

function en(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
        n = t.i18n,
        r = u.useContext(_e) || {},
        i = r.i18n,
        o = r.defaultNS,
        a = n || i || Ae();
    if (a && !a.reportNamespaces && (a.reportNamespaces = new We), !a) {
        z("You will need to pass in an i18next instance by using initReactI18next");
        var s = function(S) {
                return Array.isArray(S) ? S[S.length - 1] : S
            },
            l = [s, {}, !1];
        return l.t = s, l.i18n = {}, l.ready = !1, l
    }
    a.options.react && a.options.react.wait !== void 0 && z("It seems you are still using the old wait option, you may migrate to the new useSuspense behaviour.");
    var c = D(D(D({}, $e()), a.options.react), t),
        d = c.useSuspense,
        f = c.keyPrefix,
        p = o || a.options && a.options.defaultNS;
    p = typeof p == "string" ? [p] : p || ["translation"], a.reportNamespaces.addUsedNamespaces && a.reportNamespaces.addUsedNamespaces(p);
    var m = (a.isInitialized || a.initializedStoreOnce) && p.every(function(E) {
        return Ve(E, a, c)
    });

    function g() {
        return a.getFixedT(null, c.nsMode === "fallback" ? p : p[0], f)
    }
    var v = u.useState(g),
        h = Ie(v, 2),
        x = h[0],
        y = h[1],
        b = p.join(),
        C = qe(b),
        w = u.useRef(!0);
    u.useEffect(function() {
        var E = c.bindI18n,
            S = c.bindI18nStore;
        w.current = !0, !m && !d && te(a, p, function() {
            w.current && y(g)
        }), m && C && C !== b && w.current && y(g);

        function _() {
            w.current && y(g)
        }
        return E && a && a.on(E, _), S && a && a.store.on(S, _),
            function() {
                w.current = !1, E && a && E.split(" ").forEach(function(W) {
                    return a.off(W, _)
                }), S && a && S.split(" ").forEach(function(W) {
                    return a.store.off(W, _)
                })
            }
    }, [a, b]);
    var X = u.useRef(!0);
    u.useEffect(function() {
        w.current && !X.current && y(g), X.current = !1
    }, [a, f]);
    var j = [x, a, m];
    if (j.t = x, j.i18n = a, j.ready = m, m || !m && !d) return j;
    throw new Promise(function(E) {
        te(a, p, function() {
            E()
        })
    })
}
/**
 * @remix-run/router v1.21.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function U() {
    return U = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, U.apply(this, arguments)
}
var O;
(function(e) {
    e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE"
})(O || (O = {}));
const re = "popstate";

function He(e) {
    e === void 0 && (e = {});

    function t(i, o) {
        let {
            pathname: a = "/",
            search: s = "",
            hash: l = ""
        } = L(i.location.hash.substr(1));
        return !a.startsWith("/") && !a.startsWith(".") && (a = "/" + a), V("", {
            pathname: a,
            search: s,
            hash: l
        }, o.state && o.state.usr || null, o.state && o.state.key || "default")
    }

    function n(i, o) {
        let a = i.document.querySelector("base"),
            s = "";
        if (a && a.getAttribute("href")) {
            let l = i.location.href,
                c = l.indexOf("#");
            s = c === -1 ? l : l.slice(0, c)
        }
        return s + "#" + (typeof o == "string" ? o : F(o))
    }

    function r(i, o) {
        K(i.pathname.charAt(0) === "/", "relative pathnames are not supported in hash history.push(" + JSON.stringify(o) + ")")
    }
    return Ke(t, n, r, e)
}

function P(e, t) {
    if (e === !1 || e === null || typeof e > "u") throw new Error(t)
}

function K(e, t) {
    if (!e) {
        typeof console < "u" && console.warn(t);
        try {
            throw new Error(t)
        } catch {}
    }
}

function Je() {
    return Math.random().toString(36).substr(2, 8)
}

function ae(e, t) {
    return {
        usr: e.state,
        key: e.key,
        idx: t
    }
}

function V(e, t, n, r) {
    return n === void 0 && (n = null), U({
        pathname: typeof e == "string" ? e : e.pathname,
        search: "",
        hash: ""
    }, typeof t == "string" ? L(t) : t, {
        state: n,
        key: t && t.key || r || Je()
    })
}

function F(e) {
    let {
        pathname: t = "/",
        search: n = "",
        hash: r = ""
    } = e;
    return n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n), r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r), t
}

function L(e) {
    let t = {};
    if (e) {
        let n = e.indexOf("#");
        n >= 0 && (t.hash = e.substr(n), e = e.substr(0, n));
        let r = e.indexOf("?");
        r >= 0 && (t.search = e.substr(r), e = e.substr(0, r)), e && (t.pathname = e)
    }
    return t
}

function Ke(e, t, n, r) {
    r === void 0 && (r = {});
    let {
        window: i = document.defaultView,
        v5Compat: o = !1
    } = r, a = i.history, s = O.Pop, l = null, c = d();
    c == null && (c = 0, a.replaceState(U({}, a.state, {
        idx: c
    }), ""));

    function d() {
        return (a.state || {
            idx: null
        }).idx
    }

    function f() {
        s = O.Pop;
        let h = d(),
            x = h == null ? null : h - c;
        c = h, l && l({
            action: s,
            location: v.location,
            delta: x
        })
    }

    function p(h, x) {
        s = O.Push;
        let y = V(v.location, h, x);
        n && n(y, h), c = d() + 1;
        let b = ae(y, c),
            C = v.createHref(y);
        try {
            a.pushState(b, "", C)
        } catch (w) {
            if (w instanceof DOMException && w.name === "DataCloneError") throw w;
            i.location.assign(C)
        }
        o && l && l({
            action: s,
            location: v.location,
            delta: 1
        })
    }

    function m(h, x) {
        s = O.Replace;
        let y = V(v.location, h, x);
        n && n(y, h), c = d();
        let b = ae(y, c),
            C = v.createHref(y);
        a.replaceState(b, "", C), o && l && l({
            action: s,
            location: v.location,
            delta: 0
        })
    }

    function g(h) {
        let x = i.location.origin !== "null" ? i.location.origin : i.location.href,
            y = typeof h == "string" ? h : F(h);
        return y = y.replace(/ $/, "%20"), P(x, "No window.location.(origin|href) available to create URL for href: " + y), new URL(y, x)
    }
    let v = {
        get action() {
            return s
        },
        get location() {
            return e(i, a)
        },
        listen(h) {
            if (l) throw new Error("A history only accepts one active listener");
            return i.addEventListener(re, f), l = h, () => {
                i.removeEventListener(re, f), l = null
            }
        },
        createHref(h) {
            return t(i, h)
        },
        createURL: g,
        encodeLocation(h) {
            let x = g(h);
            return {
                pathname: x.pathname,
                search: x.search,
                hash: x.hash
            }
        },
        push: p,
        replace: m,
        go(h) {
            return a.go(h)
        }
    };
    return v
}
var ie;
(function(e) {
    e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error"
})(ie || (ie = {}));

function Ge(e, t, n) {
    return n === void 0 && (n = "/"), Ye(e, t, n)
}

function Ye(e, t, n, r) {
    let i = typeof t == "string" ? L(t) : t,
        o = G(i.pathname || "/", n);
    if (o == null) return null;
    let a = ge(e);
    Xe(a);
    let s = null;
    for (let l = 0; s == null && l < a.length; ++l) {
        let c = ut(o);
        s = ot(a[l], c)
    }
    return s
}

function ge(e, t, n, r) {
    t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = "");
    let i = (o, a, s) => {
        let l = {
            relativePath: s === void 0 ? o.path || "" : s,
            caseSensitive: o.caseSensitive === !0,
            childrenIndex: a,
            route: o
        };
        l.relativePath.startsWith("/") && (P(l.relativePath.startsWith(r), 'Absolute route path "' + l.relativePath + '" nested under path ' + ('"' + r + '" is not valid. An absolute child route path ') + "must start with the combined path of all its parent routes."), l.relativePath = l.relativePath.slice(r.length));
        let c = N([r, l.relativePath]),
            d = n.concat(l);
        o.children && o.children.length > 0 && (P(o.index !== !0, "Index routes must not have child routes. Please remove " + ('all child routes from route path "' + c + '".')), ge(o.children, t, d, c)), !(o.path == null && !o.index) && t.push({
            path: c,
            score: at(c, o.index),
            routesMeta: d
        })
    };
    return e.forEach((o, a) => {
        var s;
        if (o.path === "" || !((s = o.path) != null && s.includes("?"))) i(o, a);
        else
            for (let l of ve(o.path)) i(o, a, l)
    }), t
}

function ve(e) {
    let t = e.split("/");
    if (t.length === 0) return [];
    let [n, ...r] = t, i = n.endsWith("?"), o = n.replace(/\?$/, "");
    if (r.length === 0) return i ? [o, ""] : [o];
    let a = ve(r.join("/")),
        s = [];
    return s.push(...a.map(l => l === "" ? o : [o, l].join("/"))), i && s.push(...a), s.map(l => e.startsWith("/") && l === "" ? "/" : l)
}

function Xe(e) {
    e.sort((t, n) => t.score !== n.score ? n.score - t.score : it(t.routesMeta.map(r => r.childrenIndex), n.routesMeta.map(r => r.childrenIndex)))
}
const Qe = /^:[\w-]+$/,
    Ze = 3,
    et = 2,
    tt = 1,
    nt = 10,
    rt = -2,
    oe = e => e === "*";

function at(e, t) {
    let n = e.split("/"),
        r = n.length;
    return n.some(oe) && (r += rt), t && (r += et), n.filter(i => !oe(i)).reduce((i, o) => i + (Qe.test(o) ? Ze : o === "" ? tt : nt), r)
}

function it(e, t) {
    return e.length === t.length && e.slice(0, -1).every((r, i) => r === t[i]) ? e[e.length - 1] - t[t.length - 1] : 0
}

function ot(e, t, n) {
    let {
        routesMeta: r
    } = e, i = {}, o = "/", a = [];
    for (let s = 0; s < r.length; ++s) {
        let l = r[s],
            c = s === r.length - 1,
            d = o === "/" ? t : t.slice(o.length) || "/",
            f = lt({
                path: l.relativePath,
                caseSensitive: l.caseSensitive,
                end: c
            }, d),
            p = l.route;
        if (!f) return null;
        Object.assign(i, f.params), a.push({
            params: i,
            pathname: N([o, f.pathname]),
            pathnameBase: ht(N([o, f.pathnameBase])),
            route: p
        }), f.pathnameBase !== "/" && (o = N([o, f.pathnameBase]))
    }
    return a
}

function lt(e, t) {
    typeof e == "string" && (e = {
        path: e,
        caseSensitive: !1,
        end: !0
    });
    let [n, r] = st(e.path, e.caseSensitive, e.end), i = t.match(n);
    if (!i) return null;
    let o = i[0],
        a = o.replace(/(.)\/+$/, "$1"),
        s = i.slice(1);
    return {
        params: r.reduce((c, d, f) => {
            let {
                paramName: p,
                isOptional: m
            } = d;
            if (p === "*") {
                let v = s[f] || "";
                a = o.slice(0, o.length - v.length).replace(/(.)\/+$/, "$1")
            }
            const g = s[f];
            return m && !g ? c[p] = void 0 : c[p] = (g || "").replace(/%2F/g, "/"), c
        }, {}),
        pathname: o,
        pathnameBase: a,
        pattern: e
    }
}

function st(e, t, n) {
    t === void 0 && (t = !1), n === void 0 && (n = !0), K(e === "*" || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were ' + ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') + "always follow a `/` in the pattern. To get rid of this warning, " + ('please change the route path to "' + e.replace(/\*$/, "/*") + '".'));
    let r = [],
        i = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (a, s, l) => (r.push({
            paramName: s,
            isOptional: l != null
        }), l ? "/?([^\\/]+)?" : "/([^\\/]+)"));
    return e.endsWith("*") ? (r.push({
        paramName: "*"
    }), i += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? i += "\\/*$" : e !== "" && e !== "/" && (i += "(?:(?=\\/|$))"), [new RegExp(i, t ? void 0 : "i"), r]
}

function ut(e) {
    try {
        return e.split("/").map(t => decodeURIComponent(t).replace(/\//g, "%2F")).join("/")
    } catch (t) {
        return K(!1, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' + ("encoding (" + t + ").")), e
    }
}

function G(e, t) {
    if (t === "/") return e;
    if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
    let n = t.endsWith("/") ? t.length - 1 : t.length,
        r = e.charAt(n);
    return r && r !== "/" ? null : e.slice(n) || "/"
}

function ct(e, t) {
    t === void 0 && (t = "/");
    let {
        pathname: n,
        search: r = "",
        hash: i = ""
    } = typeof e == "string" ? L(e) : e;
    return {
        pathname: n ? n.startsWith("/") ? n : ft(n, t) : t,
        search: pt(r),
        hash: mt(i)
    }
}

function ft(e, t) {
    let n = t.replace(/\/+$/, "").split("/");
    return e.split("/").forEach(i => {
        i === ".." ? n.length > 1 && n.pop() : i !== "." && n.push(i)
    }), n.length > 1 ? n.join("/") : "/"
}

function A(e, t, n, r) {
    return "Cannot include a '" + e + "' character in a manually specified " + ("`to." + t + "` field [" + JSON.stringify(r) + "].  Please separate it out to the ") + ("`to." + n + "` field. Alternatively you may provide the full path as ") + 'a string in <Link to="..."> and the router will parse it for you.'
}

function dt(e) {
    return e.filter((t, n) => n === 0 || t.route.path && t.route.path.length > 0)
}

function ye(e, t) {
    let n = dt(e);
    return t ? n.map((r, i) => i === n.length - 1 ? r.pathname : r.pathnameBase) : n.map(r => r.pathnameBase)
}

function be(e, t, n, r) {
    r === void 0 && (r = !1);
    let i;
    typeof e == "string" ? i = L(e) : (i = U({}, e), P(!i.pathname || !i.pathname.includes("?"), A("?", "pathname", "search", i)), P(!i.pathname || !i.pathname.includes("#"), A("#", "pathname", "hash", i)), P(!i.search || !i.search.includes("#"), A("#", "search", "hash", i)));
    let o = e === "" || i.pathname === "",
        a = o ? "/" : i.pathname,
        s;
    if (a == null) s = n;
    else {
        let f = t.length - 1;
        if (!r && a.startsWith("..")) {
            let p = a.split("/");
            for (; p[0] === "..";) p.shift(), f -= 1;
            i.pathname = p.join("/")
        }
        s = f >= 0 ? t[f] : "/"
    }
    let l = ct(i, s),
        c = a && a !== "/" && a.endsWith("/"),
        d = (o || a === ".") && n.endsWith("/");
    return !l.pathname.endsWith("/") && (c || d) && (l.pathname += "/"), l
}
const N = e => e.join("/").replace(/\/\/+/g, "/"),
    ht = e => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
    pt = e => !e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e,
    mt = e => !e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e;

function gt(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.internal == "boolean" && "data" in e
}
const xe = ["post", "put", "patch", "delete"];
new Set(xe);
const vt = ["get", ...xe];
new Set(vt);
/**
 * React Router v6.28.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function T() {
    return T = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, T.apply(this, arguments)
}
const Y = u.createContext(null),
    yt = u.createContext(null),
    I = u.createContext(null),
    $ = u.createContext(null),
    R = u.createContext({
        outlet: null,
        matches: [],
        isDataRoute: !1
    }),
    Pe = u.createContext(null);

function bt(e, t) {
    let {
        relative: n
    } = t === void 0 ? {} : t;
    k() || P(!1);
    let {
        basename: r,
        navigator: i
    } = u.useContext(I), {
        hash: o,
        pathname: a,
        search: s
    } = Ee(e, {
        relative: n
    }), l = a;
    return r !== "/" && (l = a === "/" ? r : N([r, a])), i.createHref({
        pathname: l,
        search: s,
        hash: o
    })
}

function k() {
    return u.useContext($) != null
}

function B() {
    return k() || P(!1), u.useContext($).location
}

function we(e) {
    u.useContext(I).static || u.useLayoutEffect(e)
}

function Ce() {
    let {
        isDataRoute: e
    } = u.useContext(R);
    return e ? kt() : xt()
}

function xt() {
    k() || P(!1);
    let e = u.useContext(Y),
        {
            basename: t,
            future: n,
            navigator: r
        } = u.useContext(I),
        {
            matches: i
        } = u.useContext(R),
        {
            pathname: o
        } = B(),
        a = JSON.stringify(ye(i, n.v7_relativeSplatPath)),
        s = u.useRef(!1);
    return we(() => {
        s.current = !0
    }), u.useCallback(function(c, d) {
        if (d === void 0 && (d = {}), !s.current) return;
        if (typeof c == "number") {
            r.go(c);
            return
        }
        let f = be(c, JSON.parse(a), o, d.relative === "path");
        e == null && t !== "/" && (f.pathname = f.pathname === "/" ? t : N([t, f.pathname])), (d.replace ? r.replace : r.push)(f, d.state, d)
    }, [t, r, a, o, e])
}
const Pt = u.createContext(null);

function wt(e) {
    let t = u.useContext(R).outlet;
    return t && u.createElement(Pt.Provider, {
        value: e
    }, t)
}

function tn() {
    let {
        matches: e
    } = u.useContext(R), t = e[e.length - 1];
    return t ? t.params : {}
}

function Ee(e, t) {
    let {
        relative: n
    } = t === void 0 ? {} : t, {
        future: r
    } = u.useContext(I), {
        matches: i
    } = u.useContext(R), {
        pathname: o
    } = B(), a = JSON.stringify(ye(i, r.v7_relativeSplatPath));
    return u.useMemo(() => be(e, JSON.parse(a), o, n === "path"), [e, a, o, n])
}

function Ct(e, t) {
    return Et(e, t)
}

function Et(e, t, n, r) {
    k() || P(!1);
    let {
        navigator: i
    } = u.useContext(I), {
        matches: o
    } = u.useContext(R), a = o[o.length - 1], s = a ? a.params : {};
    a && a.pathname;
    let l = a ? a.pathnameBase : "/";
    a && a.route;
    let c = B(),
        d;
    if (t) {
        var f;
        let h = typeof t == "string" ? L(t) : t;
        l === "/" || (f = h.pathname) != null && f.startsWith(l) || P(!1), d = h
    } else d = c;
    let p = d.pathname || "/",
        m = p;
    if (l !== "/") {
        let h = l.replace(/^\//, "").split("/");
        m = "/" + p.replace(/^\//, "").split("/").slice(h.length).join("/")
    }
    let g = Ge(e, {
            pathname: m
        }),
        v = Lt(g && g.map(h => Object.assign({}, h, {
            params: Object.assign({}, s, h.params),
            pathname: N([l, i.encodeLocation ? i.encodeLocation(h.pathname).pathname : h.pathname]),
            pathnameBase: h.pathnameBase === "/" ? l : N([l, i.encodeLocation ? i.encodeLocation(h.pathnameBase).pathname : h.pathnameBase])
        })), o, n, r);
    return t && v ? u.createElement($.Provider, {
        value: {
            location: T({
                pathname: "/",
                search: "",
                hash: "",
                state: null,
                key: "default"
            }, d),
            navigationType: O.Pop
        }
    }, v) : v
}

function St() {
    let e = Tt(),
        t = gt(e) ? e.status + " " + e.statusText : e instanceof Error ? e.message : JSON.stringify(e),
        n = e instanceof Error ? e.stack : null,
        i = {
            padding: "0.5rem",
            backgroundColor: "rgba(200,200,200, 0.5)"
        };
    return u.createElement(u.Fragment, null, u.createElement("h2", null, "Unexpected Application Error!"), u.createElement("h3", {
        style: {
            fontStyle: "italic"
        }
    }, t), n ? u.createElement("pre", {
        style: i
    }, n) : null, null)
}
const Rt = u.createElement(St, null);
class Ot extends u.Component {
    constructor(t) {
        super(t), this.state = {
            location: t.location,
            revalidation: t.revalidation,
            error: t.error
        }
    }
    static getDerivedStateFromError(t) {
        return {
            error: t
        }
    }
    static getDerivedStateFromProps(t, n) {
        return n.location !== t.location || n.revalidation !== "idle" && t.revalidation === "idle" ? {
            error: t.error,
            location: t.location,
            revalidation: t.revalidation
        } : {
            error: t.error !== void 0 ? t.error : n.error,
            location: n.location,
            revalidation: t.revalidation || n.revalidation
        }
    }
    componentDidCatch(t, n) {
        console.error("React Router caught the following error during render", t, n)
    }
    render() {
        return this.state.error !== void 0 ? u.createElement(R.Provider, {
            value: this.props.routeContext
        }, u.createElement(Pe.Provider, {
            value: this.state.error,
            children: this.props.component
        })) : this.props.children
    }
}

function Nt(e) {
    let {
        routeContext: t,
        match: n,
        children: r
    } = e, i = u.useContext(Y);
    return i && i.static && i.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (i.staticContext._deepestRenderedBoundaryId = n.route.id), u.createElement(R.Provider, {
        value: t
    }, r)
}

function Lt(e, t, n, r) {
    var i;
    if (t === void 0 && (t = []), n === void 0 && (n = null), r === void 0 && (r = null), e == null) {
        var o;
        if (!n) return null;
        if (n.errors) e = n.matches;
        else if ((o = r) != null && o.v7_partialHydration && t.length === 0 && !n.initialized && n.matches.length > 0) e = n.matches;
        else return null
    }
    let a = e,
        s = (i = n) == null ? void 0 : i.errors;
    if (s != null) {
        let d = a.findIndex(f => f.route.id && (s == null ? void 0 : s[f.route.id]) !== void 0);
        d >= 0 || P(!1), a = a.slice(0, Math.min(a.length, d + 1))
    }
    let l = !1,
        c = -1;
    if (n && r && r.v7_partialHydration)
        for (let d = 0; d < a.length; d++) {
            let f = a[d];
            if ((f.route.HydrateFallback || f.route.hydrateFallbackElement) && (c = d), f.route.id) {
                let {
                    loaderData: p,
                    errors: m
                } = n, g = f.route.loader && p[f.route.id] === void 0 && (!m || m[f.route.id] === void 0);
                if (f.route.lazy || g) {
                    l = !0, c >= 0 ? a = a.slice(0, c + 1) : a = [a[0]];
                    break
                }
            }
        }
    return a.reduceRight((d, f, p) => {
        let m, g = !1,
            v = null,
            h = null;
        n && (m = s && f.route.id ? s[f.route.id] : void 0, v = f.route.errorElement || Rt, l && (c < 0 && p === 0 ? (Bt("route-fallback"), g = !0, h = null) : c === p && (g = !0, h = f.route.hydrateFallbackElement || null)));
        let x = t.concat(a.slice(0, p + 1)),
            y = () => {
                let b;
                return m ? b = v : g ? b = h : f.route.Component ? b = u.createElement(f.route.Component, null) : f.route.element ? b = f.route.element : b = d, u.createElement(Nt, {
                    match: f,
                    routeContext: {
                        outlet: d,
                        matches: x,
                        isDataRoute: n != null
                    },
                    children: b
                })
            };
        return n && (f.route.ErrorBoundary || f.route.errorElement || p === 0) ? u.createElement(Ot, {
            location: n.location,
            revalidation: n.revalidation,
            component: v,
            error: m,
            children: y(),
            routeContext: {
                outlet: null,
                matches: x,
                isDataRoute: !0
            }
        }) : y()
    }, null)
}
var Se = function(e) {
        return e.UseBlocker = "useBlocker", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e
    }(Se || {}),
    Re = function(e) {
        return e.UseBlocker = "useBlocker", e.UseLoaderData = "useLoaderData", e.UseActionData = "useActionData", e.UseRouteError = "useRouteError", e.UseNavigation = "useNavigation", e.UseRouteLoaderData = "useRouteLoaderData", e.UseMatches = "useMatches", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e.UseRouteId = "useRouteId", e
    }(Re || {});

function It(e) {
    let t = u.useContext(Y);
    return t || P(!1), t
}

function jt(e) {
    let t = u.useContext(yt);
    return t || P(!1), t
}

function Ut(e) {
    let t = u.useContext(R);
    return t || P(!1), t
}

function Oe(e) {
    let t = Ut(),
        n = t.matches[t.matches.length - 1];
    return n.route.id || P(!1), n.route.id
}

function Tt() {
    var e;
    let t = u.useContext(Pe),
        n = jt(),
        r = Oe();
    return t !== void 0 ? t : (e = n.errors) == null ? void 0 : e[r]
}

function kt() {
    let {
        router: e
    } = It(Se.UseNavigateStable), t = Oe(Re.UseNavigateStable), n = u.useRef(!1);
    return we(() => {
        n.current = !0
    }), u.useCallback(function(i, o) {
        o === void 0 && (o = {}), n.current && (typeof i == "number" ? e.navigate(i) : e.navigate(i, T({
            fromRouteId: t
        }, o)))
    }, [e, t])
}
const le = {};

function Bt(e, t, n) {
    le[e] || (le[e] = !0)
}
const se = {};

function _t(e, t) {
    se[t] || (se[t] = !0, console.warn(t))
}
const ue = (e, t, n) => _t(e, "⚠️ React Router Future Flag Warning: " + t + ". " + ("You can use the `" + e + "` future flag to opt-in early. ") + ("For more information, see " + n + "."));

function Ft(e, t) {
    (e == null ? void 0 : e.v7_startTransition) === void 0 && ue("v7_startTransition", "React Router will begin wrapping state updates in `React.startTransition` in v7", "https://reactrouter.com/v6/upgrading/future#v7_starttransition"), (e == null ? void 0 : e.v7_relativeSplatPath) === void 0 && ue("v7_relativeSplatPath", "Relative route resolution within Splat routes is changing in v7", "https://reactrouter.com/v6/upgrading/future#v7_relativesplatpath")
}

function nn(e) {
    return wt(e.context)
}

function $t(e) {
    P(!1)
}

function Wt(e) {
    let {
        basename: t = "/",
        children: n = null,
        location: r,
        navigationType: i = O.Pop,
        navigator: o,
        static: a = !1,
        future: s
    } = e;
    k() && P(!1);
    let l = t.replace(/^\/*/, "/"),
        c = u.useMemo(() => ({
            basename: l,
            navigator: o,
            static: a,
            future: T({
                v7_relativeSplatPath: !1
            }, s)
        }), [l, s, o, a]);
    typeof r == "string" && (r = L(r));
    let {
        pathname: d = "/",
        search: f = "",
        hash: p = "",
        state: m = null,
        key: g = "default"
    } = r, v = u.useMemo(() => {
        let h = G(d, l);
        return h == null ? null : {
            location: {
                pathname: h,
                search: f,
                hash: p,
                state: m,
                key: g
            },
            navigationType: i
        }
    }, [l, d, f, p, m, g, i]);
    return v == null ? null : u.createElement(I.Provider, {
        value: c
    }, u.createElement($.Provider, {
        children: n,
        value: v
    }))
}

function rn(e) {
    let {
        children: t,
        location: n
    } = e;
    return Ct(q(t), n)
}
new Promise(() => {});

function q(e, t) {
    t === void 0 && (t = []);
    let n = [];
    return u.Children.forEach(e, (r, i) => {
        if (!u.isValidElement(r)) return;
        let o = [...t, i];
        if (r.type === u.Fragment) {
            n.push.apply(n, q(r.props.children, o));
            return
        }
        r.type !== $t && P(!1), !r.props.index || !r.props.children || P(!1);
        let a = {
            id: r.props.id || o.join("-"),
            caseSensitive: r.props.caseSensitive,
            element: r.props.element,
            Component: r.props.Component,
            index: r.props.index,
            path: r.props.path,
            loader: r.props.loader,
            action: r.props.action,
            errorElement: r.props.errorElement,
            ErrorBoundary: r.props.ErrorBoundary,
            hasErrorBoundary: r.props.ErrorBoundary != null || r.props.errorElement != null,
            shouldRevalidate: r.props.shouldRevalidate,
            handle: r.props.handle,
            lazy: r.props.lazy
        };
        r.props.children && (a.children = q(r.props.children, o)), n.push(a)
    }), n
}
/**
 * React Router DOM v6.28.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function H() {
    return H = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, H.apply(this, arguments)
}

function Dt(e, t) {
    if (e == null) return {};
    var n = {},
        r = Object.keys(e),
        i, o;
    for (o = 0; o < r.length; o++) i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
    return n
}

function At(e) {
    return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
}

function Mt(e, t) {
    return e.button === 0 && (!t || t === "_self") && !At(e)
}

function J(e) {
    return e === void 0 && (e = ""), new URLSearchParams(typeof e == "string" || Array.isArray(e) || e instanceof URLSearchParams ? e : Object.keys(e).reduce((t, n) => {
        let r = e[n];
        return t.concat(Array.isArray(r) ? r.map(i => [n, i]) : [
            [n, r]
        ])
    }, []))
}

function zt(e, t) {
    let n = J(e);
    return t && t.forEach((r, i) => {
        n.has(i) || t.getAll(i).forEach(o => {
            n.append(i, o)
        })
    }), n
}
const Vt = ["onClick", "relative", "reloadDocument", "replace", "state", "target", "to", "preventScrollReset", "viewTransition"],
    qt = "6";
try {
    window.__reactRouterVersion = qt
} catch {}
const Ht = "startTransition",
    ce = je[Ht];

function an(e) {
    let {
        basename: t,
        children: n,
        future: r,
        window: i
    } = e, o = u.useRef();
    o.current == null && (o.current = He({
        window: i,
        v5Compat: !0
    }));
    let a = o.current,
        [s, l] = u.useState({
            action: a.action,
            location: a.location
        }),
        {
            v7_startTransition: c
        } = r || {},
        d = u.useCallback(f => {
            c && ce ? ce(() => l(f)) : l(f)
        }, [l, c]);
    return u.useLayoutEffect(() => a.listen(d), [a, d]), u.useEffect(() => Ft(r), [r]), u.createElement(Wt, {
        basename: t,
        children: n,
        location: s.location,
        navigationType: s.action,
        navigator: a,
        future: r
    })
}
const Jt = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u",
    Kt = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
    on = u.forwardRef(function(t, n) {
        let {
            onClick: r,
            relative: i,
            reloadDocument: o,
            replace: a,
            state: s,
            target: l,
            to: c,
            preventScrollReset: d,
            viewTransition: f
        } = t, p = Dt(t, Vt), {
            basename: m
        } = u.useContext(I), g, v = !1;
        if (typeof c == "string" && Kt.test(c) && (g = c, Jt)) try {
            let b = new URL(window.location.href),
                C = c.startsWith("//") ? new URL(b.protocol + c) : new URL(c),
                w = G(C.pathname, m);
            C.origin === b.origin && w != null ? c = w + C.search + C.hash : v = !0
        } catch {}
        let h = bt(c, {
                relative: i
            }),
            x = Gt(c, {
                replace: a,
                state: s,
                target: l,
                preventScrollReset: d,
                relative: i,
                viewTransition: f
            });

        function y(b) {
            r && r(b), b.defaultPrevented || x(b)
        }
        return u.createElement("a", H({}, p, {
            href: g || h,
            onClick: v || o ? r : y,
            ref: n,
            target: l
        }))
    });
var fe;
(function(e) {
    e.UseScrollRestoration = "useScrollRestoration", e.UseSubmit = "useSubmit", e.UseSubmitFetcher = "useSubmitFetcher", e.UseFetcher = "useFetcher", e.useViewTransitionState = "useViewTransitionState"
})(fe || (fe = {}));
var de;
(function(e) {
    e.UseFetcher = "useFetcher", e.UseFetchers = "useFetchers", e.UseScrollRestoration = "useScrollRestoration"
})(de || (de = {}));

function Gt(e, t) {
    let {
        target: n,
        replace: r,
        state: i,
        preventScrollReset: o,
        relative: a,
        viewTransition: s
    } = t === void 0 ? {} : t, l = Ce(), c = B(), d = Ee(e, {
        relative: a
    });
    return u.useCallback(f => {
        if (Mt(f, n)) {
            f.preventDefault();
            let p = r !== void 0 ? r : F(c) === F(d);
            l(e, {
                replace: p,
                state: i,
                preventScrollReset: o,
                relative: a,
                viewTransition: s
            })
        }
    }, [c, l, d, r, i, n, e, o, a, s])
}

function ln(e) {
    let t = u.useRef(J(e)),
        n = u.useRef(!1),
        r = B(),
        i = u.useMemo(() => zt(r.search, n.current ? null : t.current), [r.search]),
        o = Ce(),
        a = u.useCallback((s, l) => {
            const c = J(typeof s == "function" ? s(i) : s);
            n.current = !0, o("?" + c, l)
        }, [o, i]);
    return [i, a]
}
const Yt = "modulepreload",
    Xt = function(e) {
        return "/" + e
    },
    he = {},
    sn = function(t, n, r) {
        let i = Promise.resolve();
        if (n && n.length > 0) {
            document.getElementsByTagName("link");
            const a = document.querySelector("meta[property=csp-nonce]"),
                s = (a == null ? void 0 : a.nonce) || (a == null ? void 0 : a.getAttribute("nonce"));
            i = Promise.allSettled(n.map(l => {
                if (l = Xt(l), l in he) return;
                he[l] = !0;
                const c = l.endsWith(".css"),
                    d = c ? '[rel="stylesheet"]' : "";
                if (document.querySelector(`link[href="${l}"]${d}`)) return;
                const f = document.createElement("link");
                if (f.rel = c ? "stylesheet" : Yt, c || (f.as = "script"), f.crossOrigin = "", f.href = l, s && f.setAttribute("nonce", s), document.head.appendChild(f), c) return new Promise((p, m) => {
                    f.addEventListener("load", p), f.addEventListener("error", () => m(new Error(`Unable to preload CSS for ${l}`)))
                })
            }))
        }

        function o(a) {
            const s = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (s.payload = a, window.dispatchEvent(s), !s.defaultPrevented) throw a
        }
        return i.then(a => {
            for (const s of a || []) s.status === "rejected" && o(s.reason);
            return t().catch(o)
        })
    };

function un(e) {
    throw new Error('Could not dynamically require "' + e + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')
}
export {
    an as H, on as L, nn as O, rn as R, sn as _, B as a, Ce as b, tn as c, wt as d, ln as e, un as f, $t as g, Zt as i, en as u
};